import time
import matplotlib.pyplot as plt
from matplotlib import style
style.use('ggplot')
import pandas as pd
import numpy as np
from numpy import r_,c_

from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split
#from sklearn.metrics import confusion_matrix



def cost_function(m,lamb,theta,x_train,y_train):  
    new_theta = theta[1:,:]
    J = (1.0/(2*m)) * np.sum( (np.dot(x_train, theta) - y_train)**2) + float(lamb)/(2*m) * np.sum(new_theta**2)
    return J 

def gradients(m,lamb,theta,x_train,y_train):
    theta_0 = (1.0/m) * np.sum(np.dot(x_train, theta) - y_train) * 1.0
    theta_j = (1.0/m) * np.sum(np.dot((np.dot(x_train, theta) - y_train).T,x_train)) + float(lamb)/(2*m)*theta
    return theta_0,theta_j[1:,:]

if __name__== '__main__':
    alpha = 0.08
    lamb = 0.05
    iterations = 1000
    df = datasets.load_diabetes()
    y = np.array([df.target]).T
    x = df.data

    #for i in range(x.shape[1]):
    #    x[:,i] = (x[:,i] -np.amax(x[:,i]))/(np.amax(x[:,i]) - np.amin(x[:,i]))

    x_train, x_test,y_train,y_test = train_test_split(x,y,test_size = 0.2, random_state = 1)
  
    x_train =  c_[ np.ones([x_train.shape[0],1]),x_train ]
    x_test = c_[ np.ones([x_test.shape[0],1]),x_test ]
    theta = np.random.rand(x.shape[1]+1,1)
    cost = []
    cost.append( cost_function(x_train.shape[0], lamb, theta, x_train, y_train) )
    for i in range(iterations):
        grads = gradients(x_train.shape[0],lamb,theta,x_train,y_train)
        theta[0,:] = theta[0,:] - alpha*grads[0]
        theta[1:,:] = theta[1:,:] - alpha*grads[1]
        cost.append( cost_function(x_train.shape[0], lamb, theta, x_train, y_train) )


    plt.plot(cost)
    plt.show()
    
    clf = linear_model.LinearRegression()
    clf.fit(x_train, y_train)

    prediction = np.dot(x_train,theta)
    clf_predict = []

    for i in range(y_train.shape[0]):
        clf_predict.append(clf.predict([x_train[i,:]]))
   # print(clf_predict[:10])    
    new = np.squeeze(clf_predict)
    #clf_predict.shape
    a,  = plt.plot(y_train, label='y_train')
    b,  = plt.plot(new, label= 'clf_predict')
    c,  = plt.plot(prediction, label='own prediction')
    plt.legend(handles=[a,b,c])
   
    plt.show()
    
