function [C, sigma] = dataset3Params(X, y, Xval, yval)
%DATASET3PARAMS returns your choice of C and sigma for Part 3 of the exercise
%where you select the optimal (C, sigma) learning parameters to use for SVM
%with RBF kernel
%   [C, sigma] = DATASET3PARAMS(X, y, Xval, yval) returns your choice of C and 
%   sigma. You should complete this function to return the optimal C and 
%   sigma based on a cross-validation set.
%

% You need to return the following variables correctly.
C = 0.3;
sigma = 0.03;

% ====================== YOUR CODE HERE ======================
% Instructions: Fill in this function to return the optimal C and sigma
%               learning parameters found using the cross validation set.
%               You can use svmPredict to predict the labels on the cross
%               validation set. For example, 
%                   predictions = svmPredict(model, Xval);
%               will return the predictions on the cross validation set.
%
%  Note: You can compute the prediction error using 
%        mean(double(predictions ~= yval))
%                    
                   C1 = [0.1,0.3,1,3,10,30];
                   sigma1 = [0.1,0.3,1,3,10,30];
                   
                  m1 = size(C1,2);
                   prd_err = zeros(m1,m1);
                   
                   for i = 1:m1
                      for j = 1:m1  
                       model = svmTrain(Xval,yval,C1(i),@(x1,x2) gaussianKernel(x1,x2,sigma1(j)));
                       pred = svmPredict(model,Xval);
                       prd_err(i,j) = mean(double(pred ~= yval));
                       y1 = not(yval);
                       pred1 = not(pred);
                       tp = sum(and(pred,yval)); 
                       fp = sum(and(pred,y1));
                       fn = sum(and(pred1,yval));
                       pr = tp/(tp+fp);
                       rc = tp/(tp+fn);
                       F1(i,j) = (2*pr*rc)/(pr+rc);
                        
                      end
                                            

                   end
                  
                   for i =1:m1
                       F11(i) = mean(F1(i,:));
                       F12(i) = mean(F1(:,i));
                   end 
                   [row,column] = find(F11==max(max(F11))); 
                      C = C1(1,column);
                   [row,column] = find(F12==max(max(F12)));
                      sigma = sigma1(1,column); 
                        


% =========================================================================

end
